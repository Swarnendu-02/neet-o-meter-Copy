<?php include_once("includes/pagesource.php"); ?>

<body>
    <?php include_once("includes/header.php"); ?>
    <div class="container-fluid banner p-0 position-relative overflow-hidden">
        <img src="images/content-styled-image-new.png" class="banner-bk">
        <img class="hero-shape-3" src="images/hero-shape-3.png" alt="lmsmart">
        <img class="hero-shape-4" src="images/hero-shape-4.png" alt="lmsmart">
        <img class="hero-shape-2" src="images/hero-shape-2.png" alt="lmsmart">
        <div class="shap-1">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;" xml:space="preserve">
                <g>
                    <path d="M37.5,25c0,6.5-2.6,12.7-7.3,17.3c-4.7,4.6-11,7.2-17.7,7.2V39.1c7.9,0,14.4-6.3,14.4-14.1c0-7.8-6.5-14.1-14.4-14.1V0.5  c6.7,0,13,2.5,17.7,7.2C34.9,12.3,37.5,18.5,37.5,25z"></path>
                </g>
            </svg>
        </div>
        <div class="shap-2">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;" xml:space="preserve">
                <g>
                    <circle cx="25" cy="25" r="24"></circle>
                </g>
            </svg>
        </div>
        <div class="shap-3">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;" xml:space="preserve">
                <g>
                    <path d="M37.5,25c0,6.5-2.6,12.7-7.3,17.3c-4.7,4.6-11,7.2-17.7,7.2V39.1c7.9,0,14.4-6.3,14.4-14.1c0-7.8-6.5-14.1-14.4-14.1V0.5  c6.7,0,13,2.5,17.7,7.2C34.9,12.3,37.5,18.5,37.5,25z"></path>
                </g>
            </svg>
        </div>
        <div class="shap-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="503" height="840" viewBox="0 0 503 840">
                <path d="M410.866,840H0.015c0-255.632,100.9-495.958,284.105-676.714s426.8-280.3,685.891-280.3V288.338C661.7,288.338,410.866,535.809,410.866,840Z" />
            </svg>
        </div>
        <div class="container position-relative h-100" style="z-index: 1;">
            <div class="row align-items-center h-100">
                <div class="col-12 col-md-6 banner-content">
                    <div>
                        <h2 class="animate__zoomIn animate__ wow" style="visibility: visible;">THE MOST PROGRESSIVE <span>EDUCATIONAL</span> STATUS METER</h2>
                    </div>
                </div>
                <div class="col-12 col-md-6 position-relative">
                    <img src="images/meter-bk.png" class="meter-bk">
                    <img src="images/cibil_score.gif" class="w-100 position-relative">
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative service-main-wrap">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 why-wrap">
                    <div class="why-box row p-0 m-0">
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box " style="    background: #ec870326;">
                                <img src="images/education (1).png">
                                <h4>Scholarship Facility</h4>
                                <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown</p>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box " style="background: #ec870326;">
                                <img src="images/candidate.png">
                                <h4>Skilled Lecturers</h4>
                                <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown</p>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box " style="background: #ec870326;">
                                <img src="images/book.png">
                                <h4>Book Library & Store</h4>
                                <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row ">
                <div class="col-md-12">
                    <div class="d-md-flex align-items-center justify-content-between">
                        <div class="main-heaing abt-left">
                            <h6>About NEET-O-METER</h6>
                            <h2 class="animate__fadeInUp animate__animated wow mb-4">Qualified And Highly <span>Equipped Tutors</span></h2>
                            <p class="mt-3">NEET-O-METER App is a mobile learning application to start eLearning fast and let the students take courses on the go. The app was based on the idea of the frequent presence of modern users on the mobile platform.</p>
                            <p class="mt-3 ">NEET-O-METER App is a mobile learning application to start eLearning fast and let the students take courses on the go. The app was based on the idea of the frequent presence of modern users on the mobile platform.</p>
                            <p class="mt-3 ">NEET-O-METER App is a mobile learning application to start eLearning fast and let the students take courses on the go. The app was based on the idea of the frequent presence of modern users on the mobile platform.</p>
                            <a href="#" class="main-btn-red mt-5">Know More</a>
                        </div>
                        <div class="abt-rt">
                            <img src="images/adv1.jpeg" class="abt-rt-lrg">
                            <img src="images/adv10.jpeg" class="abt-rt-small">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 about-wrap position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row ">
                <div class="col-12 abt-main-wrap d-md-flex justify-content-between">
                    <div class="col-12 col-md-6">
                        <div class="col-12 main-heaing">
                            <h2 class="animate__fadeInUp animate__animated wow text-white">Preparing for <span>NEET?</span> Come learn at NEET-O-METER</h2>
                        </div>
                        <div class="col-12  about-counter-cell">

                            <div class=" d-md-flex align-items-center ">
                                <div class="col-md-4 mr-md-5">
                                    <canvas id="chart2"></canvas>
                                </div>
                                <div>
                                    <h4><span class="counter wow" data-target="12000"></span>+</h4>
                                    <h6>CONCEPTS</h6>
                                </div>
                            </div>
                            <div class=" d-md-flex align-items-center ">
                                <div class="col-md-4 mr-md-5">
                                    <canvas id="chart3"></canvas>
                                </div>
                                <div>
                                    <h4><span class="counter wow" data-target="12000"></span>+</h4>
                                    <h6>VIDEO e-LECTURES</h6>
                                </div>
                            </div>
                            <div class=" d-md-flex align-items-center ">
                                <div class="col-md-4 mr-md-5">
                                    <canvas id="chart4"></canvas>
                                </div>
                                <div>
                                    <h4><span class="counter wow" data-target="12000"></span>+</h4>
                                    <h6>FACULTY SUPPORT</h6>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-12 col-md-6 abt-info">

                        <div class="content text-white mt-4 mt-md-0">
                            <p class="animate__fadeInUp animate__animated wow">Prepare for NEET 2022 or 2023 with the most thorough and exhaustive online homeroom program by the world's biggest Ed-Tech organization.</p>

                            <p class="animate__fadeInUp animate__animated wow">Ordinary online classes by India's driving NEET coaches</p>

                            <p class="animate__fadeInUp animate__animated wow">NEET-O-METER offer you Online Classes that will be directed 3-5 times each week by India's Best NEET Trainers. This will assist you with understanding the idea altogether and guarantee that every one of your questions is cleared.</p>

                            <p class="animate__fadeInUp animate__animated wow">In-depth conversation of Daily Practice Problems (DPPs) and Practice Sheets</p>

                            <p class="animate__fadeInUp animate__animated wow">The very much planned and organized DPP will help you amend the ideas consistently for every one of the subjects. Practice Sheet conversation guarantees that you figure out how to apply the ideas educated in the class.</p>

                            <p class="animate__fadeInUp animate__animated wow">All India Tests to benchmark yourself against different students</p>

                            <p class="animate__fadeInUp animate__animated wow">NEET-O-METER All India Test Series (AITS) for NEET led once at regular intervals will measure your exhibition PAN India and improve your test-taking abilities. Each test is trailed by definite input to assist you with understanding the holes in your planning.</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid  py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="animate__fadeInUp animate__animated wow text-center">Start your <span>NEET</span> preparation now</h2>
                    <p class="animate__fadeInUp animate__animated wow text-center">You don't have to struggle alone, you've got our assistance and help.</p>
                </div>
                <div class="col-12 tabcontent active">
                    <div class="team-box row mb-5">
                        <div class="prep-cell animate__fadeInUp animate__animated wow" style="background:#DD246E;">
                            <div class="prep-img-box">
                                <img src="images/study-material.png">
                            </div>
                            <h4>Smart Study Material</h4>
                            <ul>
                                <li>20000+ Chapter wise <b>NEET questions</b></li>
                                <li>5000+ NEET concept wise <b>videos</b></li>
                                <li>1200+ Most asked <b>NEET concepts</b></li>
                                <li>1000+ Most difficult <b>NEET concepts</b></li>
                                <li>10 years solved <b>NEET question papers</b></li>
                                <li>5000+ Concept wise <b>Flash Cards</b></li>
                                <li>Weekend <b>Live Classes</b></li>
                            </ul>
                        </div>


                        <div class="prep-cell animate__fadeInUp animate__animated wow" style="background:#8007E6 ;">
                            <div class="prep-img-box">
                                <img src="images/mocktest.png">
                            </div>
                            <h4>NEET Mock Test Series</h4>
                            <ul>
                                <li>Unlimited - <b>chapter wise tests</b></li>
                                <li>Unlimited - <b>subject wise tests</b></li>
                                <li>Unlimited - <b>Full mock tests</b></li>
                            </ul>
                        </div>


                        <div class="prep-cell animate__fadeInUp animate__animated wow" style="background:#0CAE74;">
                            <div class="prep-img-box">
                                <img src="images/performance.png">
                            </div>
                            <h4>Performance Analysis</h4>
                            <ul>
                                <li><b>Prepmeter</b> - Check how ready you are for NEET</li>
                                <li><b>Strength Sheet</b> - Know your top performing areas</li>
                                <li><b>Weakness Sheet</b> - Know your areas to improve</li>
                                <li><b>Skills Graph</b> - Know how your skill-set is improving</li>
                                <li><b>Rank Predictor</b> - Estimate your rank in advance</li>
                            </ul>
                        </div>
                    </div>
                    <h4 class="prep-btm-text animate__fadeInUp animate__animated wow">Live NEET doubt solving with <span>24x7</span> faculty support</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative featr-wrap">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h6 class="text-white text-center">Advance systems make us uniq, help you to grow your career</h6>
                    <h2 class=" text-center animate__fadeInUp animate__animated wow text-white">Feature Of <span>NEET-O-METER.</span></h2>
                </div>
                <div class="col-12 why-wrap">
                    <div class="why-box row p-0 m-0">
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/ai.png">
                                <h4>AI DRIVEN PERSONALISED MENTOR</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/mocktest.png">
                                <h4>UNLIMITED MOCK TEST+ PREVIOUS PAPERS</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/timetable.png">
                                <h4>CUSTOMISED TIMETABLE</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/performance.png">
                                <h4>PERFORNMENCE ANALYSIS</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/exam.png">
                                <h4>EXAM STRATEGY PLANNING</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/study-material.png">
                                <h4>SMART STUDY MATERIAL</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid py-6 meter-sec">
        <div class="container position-relative">
            <div class="row align-items-center justify-content-between">
                <div class="col-12 col-md-5 meter-wrap">
                    <div>
                        <h5>Correct</h5>
                        <canvas id="chart5"></canvas>
                    </div>
                    <div>
                        <h5>In-correct</h5>
                        <canvas id="chart6"></canvas>
                    </div>
                    <div>
                        <h5>Correct</h5>
                        <canvas id="chart7"></canvas>
                    </div>
                    <div>
                        <h5>Correct</h5>
                        <canvas id="chart8"></canvas>
                    </div>
                </div>
                <div class="col-12 col-md-5">
                    <div class="col-12 main-heaing">
                        <h2 class="animate__fadeInUp animate__animated wow ">Take Your Result Status</h2>
                    </div>
                    <div class="content-2 mb-0  animate__fadeInUp animate__animated wow ">
                        <p>NEET-O-METER App is a mobile learning application to start eLearning fast and let the
                            students take courses on the go. The app was based on the idea of the frequent presence of
                            modern users on the mobile platform.</p>
                    </div>

                </div>

            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative price-wrap" id="plans">
        <img src="images/get_masterstudy_background.png" class="price-bk">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center animate__fadeInUp animate__ wow  animated" style="visibility: visible;">Learn Prep Plans now</h2>
                </div>
                <div class="col-12 tabcontent">
                    <div class="team-box row m-0 p-0">

                        <div class="prep-cell p-0 animate__fadeInUp animate__ wow  animated" style="visibility: visible;">
                            <div class="price-box blue">
                                <h2 class="price"><i class="fas fa-rupee-sign"></i> 14999<br><span>per month</span></h2>

                                <div class="price-cell">
                                    <h3 class="course-name">CRASH COURSE</h3>
                                    <ul class="course-detail">
                                        <li>1x option 1</li>
                                        <li>2x option 2</li>
                                        <li>3x option 3</li>
                                        <li>Free option 4</li>
                                        <li>Unlimited option 5</li>
                                    </ul>
                                    <a>Buy Now</a>
                                </div>
                            </div>
                        </div>
                        <div class="prep-cell p-0 animate__fadeInUp animate__ wow  animated" style="visibility: visible;">
                            <div class="price-box pink">
                                <h2 class="price"><i class="fas fa-rupee-sign"></i> 24999<br><span>per month</span></h2>

                                <div class="price-cell">
                                    <h3 class="course-name">CRASH COURSE2</h3>
                                    <ul class="course-detail">
                                        <li>1x option 1</li>
                                        <li>2x option 2</li>
                                        <li>3x option 3</li>
                                        <li>Free option 4</li>
                                        <li>Unlimited option 5</li>
                                    </ul>
                                    <a>Buy Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative app-wrap" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row ">
                <div class="col-md-12">
                    <div class="d-md-flex align-items-center justify-content-between">
                        <div class="main-heaing app-left">
                            <h2 class="animate__fadeInUp animate__animated wow mb-5">NEET-O-METER App For <span>IOS & Android</span></h2>
                            <p class="mt-3 mb-4">NEET-O-METER App is a mobile learning application to start eLearning fast and let the students take courses on the go. The app was based on the idea of the frequent presence of modern users on the mobile platform.</p>
                            <div class="download-box">
                 
                                <a class="animate__fadeInUp animate__animated wow"><img src="images/android.png"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative vdo-wrap" style="overflow:hidden;">
        <div class="vdo-rt">
            <img src="images/kenny-eliason-1-aA2Fadydc-unsplash.jpg" class="vdo-thumb">
            <button><img src="images/play.png"></button>
        </div>
        <div class="container position-relative">
            <div class="row ">
                <div class="col-md-12">
                    <div class="d-md-flex align-items-center justify-content-between">
                        <div class="main-heaing vdo-lft">
                            <h6>Learn in live</h6>
                            <h2 class="animate__fadeInUp animate__animated wow mb-5">Live Online <span>Sessions</span></h2>
                            <p class="mt-3 mb-5">At in tellus integer feugiat scelerisque varius. Suspendisse faucibus interdum posuere lorem ipsum dolor sit amet consectetur. Vitae purus faucibus ornare suspendisse sed nisi lacus. In egestas erat imperdiet sed euismod. Donec pretium vulputate sapien nec sagittis gceleriste.</p>
                            <div class="vdo-box mt-3">
                                <a class="animate__fadeInUp animate__animated wow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="64px" height="52px">
                                        <path fill-rule="evenodd" fill="currentcolor" d="M59.973,40.411 C59.616,41.108 59.064,41.439 58.441,41.332 C57.783,41.217 57.316,40.828 57.255,40.173 C57.220,39.787 57.357,39.348 57.534,38.988 C58.907,36.203 59.857,33.290 60.263,30.209 C61.193,23.164 59.692,16.666 55.780,10.716 C55.647,10.513 55.500,10.318 55.387,10.104 C55.042,9.448 55.220,8.697 55.805,8.288 C56.420,7.858 57.233,7.942 57.708,8.558 C58.164,9.152 58.567,9.788 58.952,10.430 C61.900,15.342 63.354,20.666 63.389,26.183 C63.353,31.320 62.233,36.002 59.973,40.411 ZM48.957,33.898 C48.131,33.609 47.806,32.837 48.144,31.904 C49.970,26.872 49.425,22.113 46.488,17.624 C45.951,16.804 46.053,16.003 46.739,15.529 C47.455,15.036 48.282,15.236 48.841,16.062 C50.934,19.157 51.995,22.567 52.013,26.293 C52.030,28.561 51.619,30.749 50.805,32.865 C50.454,33.775 49.743,34.174 48.957,33.898 ZM40.669,15.317 C40.669,18.245 40.686,21.172 40.651,24.099 C40.645,24.526 40.478,25.011 40.230,25.360 C39.919,25.799 39.384,25.905 38.847,25.733 C38.297,25.555 37.942,25.184 37.866,24.600 C37.832,24.340 37.841,24.075 37.841,23.811 C37.840,18.200 37.844,12.588 37.837,6.977 C37.835,5.244 36.881,3.995 35.326,3.854 C34.731,3.801 34.033,3.978 33.502,4.267 C29.694,6.338 25.917,8.466 22.131,10.574 C21.957,10.671 21.786,10.775 21.606,10.861 C20.841,11.219 20.030,10.976 19.661,10.279 C19.304,9.606 19.521,8.818 20.243,8.404 C21.758,7.534 23.293,6.698 24.818,5.847 C27.272,4.480 29.728,3.117 32.177,1.742 C35.937,-0.367 40.582,2.238 40.656,6.539 C40.706,9.465 40.665,12.392 40.665,15.317 C40.667,15.317 40.668,15.317 40.669,15.317 ZM58.081,45.341 C58.271,45.493 58.467,45.639 58.640,45.806 C59.218,46.369 59.265,47.194 58.762,47.768 C58.258,48.345 57.450,48.428 56.788,47.919 C55.826,47.176 54.889,46.401 53.941,45.639 C49.684,42.222 45.428,38.803 41.170,35.385 C41.039,35.280 40.900,35.185 40.669,35.016 C40.669,35.366 40.669,35.600 40.669,35.832 C40.668,39.243 40.692,42.654 40.660,46.063 C40.629,49.283 37.910,51.855 34.694,51.648 C33.842,51.593 32.937,51.307 32.186,50.896 C26.060,47.533 19.968,44.113 13.855,40.727 C13.527,40.545 13.110,40.446 12.732,40.440 C10.981,40.409 9.228,40.444 7.476,40.423 C3.751,40.376 0.976,37.772 0.924,34.106 C0.852,28.915 0.848,23.721 0.927,18.529 C0.982,14.889 3.745,12.300 7.436,12.241 C8.987,12.218 10.539,12.238 12.090,12.238 C12.113,12.189 12.135,12.140 12.158,12.092 C11.046,11.197 9.935,10.303 8.822,9.411 C7.840,8.620 6.854,7.837 5.875,7.044 C5.085,6.404 4.942,5.584 5.489,4.918 C6.029,4.261 6.873,4.227 7.667,4.863 C15.461,11.115 23.251,17.370 31.042,23.624 C40.056,30.862 49.068,38.101 58.081,45.341 ZM12.241,15.076 C10.673,15.076 9.148,15.071 7.623,15.077 C5.200,15.084 3.772,16.486 3.765,18.874 C3.758,21.338 3.763,23.801 3.764,26.264 C3.764,28.881 3.746,31.496 3.775,34.111 C3.794,35.851 5.037,37.396 6.692,37.514 C8.517,37.645 10.360,37.545 12.241,37.545 C12.241,30.028 12.241,22.585 12.241,15.076 ZM15.149,14.498 C15.128,14.719 15.114,14.803 15.114,14.885 C15.112,22.498 15.109,30.110 15.131,37.724 C15.131,37.958 15.346,38.292 15.557,38.410 C21.574,41.787 27.596,45.151 33.640,48.477 C34.128,48.745 34.795,48.864 35.352,48.806 C36.861,48.647 37.828,47.434 37.834,45.792 C37.849,41.589 37.847,37.387 37.821,33.185 C37.820,32.915 37.624,32.559 37.406,32.383 C31.645,27.731 25.871,23.095 20.098,18.459 C18.482,17.162 16.862,15.867 15.149,14.498 Z"></path>
                                    </svg><br>Noiceless</a>
                                <a class="animate__fadeInUp animate__animated wow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="64px" height="39px">
                                        <path fill-rule="evenodd" fill="currentcolor" d="M61.505,34.787 C60.696,35.040 59.907,34.973 59.160,34.573 C55.529,32.617 51.896,30.667 48.275,28.693 C47.208,28.111 46.641,27.168 46.639,25.927 C46.631,21.525 46.631,17.126 46.639,12.724 C46.642,11.457 47.241,10.519 48.330,9.927 C51.898,7.986 55.468,6.050 59.051,4.137 C60.925,3.136 62.896,3.984 63.572,6.033 C63.597,6.109 63.647,6.174 63.686,6.244 C63.686,14.966 63.686,23.689 63.686,32.411 C63.300,33.524 62.679,34.419 61.505,34.787 ZM60.550,6.937 C60.434,6.977 60.354,6.994 60.285,7.030 C56.893,8.861 53.506,10.702 50.105,12.516 C49.747,12.708 49.732,12.954 49.732,13.278 C49.735,17.303 49.742,21.328 49.723,25.352 C49.721,25.797 49.875,26.015 50.247,26.214 C53.537,27.974 56.816,29.753 60.100,31.523 C60.237,31.597 60.388,31.646 60.550,31.714 C60.550,23.433 60.550,15.207 60.550,6.937 ZM35.407,38.186 C25.826,38.191 16.244,38.191 6.662,38.187 C2.725,38.186 0.092,35.508 0.091,31.516 C0.089,23.384 0.089,15.250 0.091,7.118 C0.092,3.137 2.734,0.472 6.682,0.468 C11.462,0.465 16.243,0.467 21.024,0.467 C25.887,0.468 30.750,0.454 35.614,0.472 C38.877,0.484 41.371,2.634 41.895,5.854 C41.962,6.263 41.959,6.689 41.959,7.106 C41.962,15.260 41.965,23.414 41.960,31.567 C41.958,35.520 39.320,38.186 35.407,38.186 ZM35.423,3.613 C30.642,3.611 25.862,3.613 21.082,3.613 C16.240,3.613 11.398,3.610 6.556,3.613 C4.474,3.614 3.196,4.914 3.195,7.028 C3.193,15.224 3.193,23.418 3.195,31.613 C3.196,33.757 4.473,35.042 6.605,35.043 C16.228,35.045 25.850,35.045 35.472,35.043 C37.597,35.042 38.857,33.760 38.858,31.594 C38.860,23.421 38.860,15.247 38.858,7.073 C38.857,4.872 37.603,3.613 35.423,3.613 Z"></path>
                                    </svg><br>Recording</a>
                                <a class="animate__fadeInUp animate__animated wow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="56px" height="46px">
                                        <path fill-rule="evenodd" fill="currentcolor" d="M48.730,45.500 C34.760,45.502 20.791,45.503 6.822,45.499 C3.646,45.498 1.160,43.553 0.496,40.534 C0.375,39.984 0.338,39.404 0.337,38.840 C0.328,28.192 0.328,17.546 0.332,6.900 C0.333,2.898 3.001,0.233 6.992,0.232 C13.937,0.232 20.883,0.232 27.829,0.232 C34.852,0.232 41.876,0.226 48.900,0.235 C52.017,0.239 54.496,2.221 55.145,5.225 C55.260,5.758 55.296,6.316 55.297,6.864 C55.305,17.530 55.306,28.196 55.301,38.862 C55.300,42.802 52.625,45.500 48.730,45.500 ZM52.785,6.834 C52.784,4.279 51.241,2.738 48.688,2.738 C34.774,2.737 20.860,2.737 6.946,2.738 C4.396,2.738 2.850,4.281 2.849,6.832 C2.846,17.521 2.847,28.210 2.851,38.898 C2.852,39.288 2.861,39.690 2.949,40.067 C3.372,41.890 4.862,42.994 6.887,42.995 C13.853,42.999 20.820,42.996 27.787,42.996 C34.753,42.996 41.720,42.998 48.687,42.995 C51.238,42.995 52.784,41.452 52.785,38.900 C52.788,28.211 52.788,17.522 52.785,6.834 ZM47.920,40.445 C46.224,40.478 44.528,40.468 42.833,40.452 C42.079,40.443 41.563,39.894 41.575,39.190 C41.587,38.489 42.115,37.968 42.874,37.962 C44.491,37.948 46.107,37.957 47.810,37.957 C47.810,37.448 47.809,37.020 47.810,36.592 C47.812,35.356 47.798,34.118 47.824,32.884 C47.839,32.207 48.329,31.734 48.966,31.699 C49.632,31.661 50.257,32.107 50.271,32.774 C50.310,34.617 50.344,36.465 50.254,38.305 C50.194,39.510 49.126,40.422 47.920,40.445 ZM49.031,14.046 C48.319,14.037 47.825,13.534 47.816,12.747 C47.799,11.334 47.810,9.919 47.810,8.506 C47.809,8.293 47.810,8.079 47.810,7.777 C46.251,7.777 44.772,7.777 43.292,7.777 C43.078,7.777 42.860,7.789 42.650,7.759 C42.011,7.666 41.562,7.125 41.577,6.489 C41.593,5.843 42.056,5.302 42.711,5.292 C44.504,5.267 46.300,5.246 48.092,5.304 C49.279,5.343 50.262,6.427 50.286,7.660 C50.320,9.368 50.308,11.078 50.290,12.785 C50.282,13.545 49.742,14.054 49.031,14.046 ZM33.416,21.904 C34.110,22.905 34.789,23.882 35.470,24.861 C36.567,26.437 37.676,28.004 38.758,29.591 C39.374,30.494 38.899,31.590 37.883,31.653 C37.315,31.689 36.943,31.370 36.634,30.923 C35.106,28.715 33.570,26.515 32.035,24.313 C31.925,24.156 31.807,24.004 31.660,23.803 C31.234,24.262 30.820,24.672 30.455,25.122 C30.338,25.266 30.313,25.519 30.311,25.721 C30.300,27.214 30.310,28.707 30.303,30.201 C30.299,31.104 29.812,31.678 29.071,31.683 C28.326,31.687 27.819,31.103 27.819,30.216 C27.816,25.304 27.815,20.392 27.819,15.478 C27.820,14.628 28.315,14.055 29.038,14.038 C29.779,14.020 30.298,14.600 30.302,15.485 C30.310,17.253 30.305,19.023 30.305,20.790 C30.305,20.982 30.305,21.173 30.305,21.365 C30.348,21.387 30.391,21.408 30.434,21.429 C31.617,20.155 32.801,18.882 33.984,17.607 C34.904,16.617 35.818,15.622 36.742,14.635 C37.371,13.964 38.082,13.880 38.645,14.395 C39.220,14.919 39.187,15.676 38.548,16.367 C36.848,18.206 35.144,20.041 33.416,21.904 ZM22.428,31.594 C21.884,31.413 21.588,30.968 21.585,30.262 C21.577,28.455 21.582,26.650 21.582,24.844 C21.582,24.632 21.582,24.422 21.582,24.134 C21.311,24.134 21.104,24.134 20.896,24.134 C19.141,24.134 17.386,24.130 15.631,24.136 C15.002,24.140 14.454,23.992 14.191,23.355 C13.932,22.726 14.182,22.235 14.638,21.779 C17.019,19.398 19.390,17.010 21.754,14.615 C22.207,14.155 22.698,13.902 23.323,14.180 C23.917,14.445 24.076,14.961 24.075,15.583 C24.066,20.451 24.072,25.320 24.069,30.190 C24.068,31.258 23.319,31.889 22.428,31.594 ZM21.539,18.589 C20.559,19.575 19.564,20.575 18.584,21.561 C19.523,21.561 20.520,21.561 21.539,21.561 C21.539,20.520 21.539,19.518 21.539,18.589 ZM12.754,7.773 C11.350,7.785 9.946,7.777 8.542,7.777 C8.329,7.777 8.117,7.777 7.823,7.777 C7.823,9.470 7.830,11.078 7.820,12.684 C7.816,13.401 7.470,13.879 6.899,14.016 C6.113,14.205 5.363,13.677 5.349,12.849 C5.320,11.084 5.302,9.316 5.359,7.550 C5.399,6.306 6.459,5.311 7.708,5.287 C9.404,5.253 11.101,5.264 12.797,5.280 C13.551,5.286 14.089,5.825 14.092,6.513 C14.096,7.224 13.542,7.765 12.754,7.773 ZM6.610,31.697 C7.301,31.709 7.803,32.197 7.814,32.943 C7.835,34.375 7.823,35.806 7.824,37.239 C7.824,37.451 7.824,37.664 7.824,37.957 C9.526,37.957 11.142,37.945 12.758,37.962 C13.719,37.971 14.314,38.777 14.008,39.623 C13.824,40.132 13.456,40.442 12.912,40.447 C11.139,40.459 9.365,40.484 7.593,40.435 C6.372,40.398 5.371,39.324 5.347,38.069 C5.315,36.364 5.326,34.655 5.344,32.949 C5.352,32.197 5.901,31.686 6.610,31.697 Z"></path>
                                    </svg><br>High Quality</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 pb-0 position-relative nps-sec" style="overflow:hidden;">
        <img src="images/destination-3d-render-icon-illustration-png.png" class="nps-bk">
        <div class="container position-relative">
            <div class="row ">
                <div class="col-12 main-heaing">
                    <h2 class="animate__fadeInUp animate__animated wow  text-center">NEET <span>Positioning System</span></h2>
                    <p class=" text-center animate__fadeInUp animate__animated wow">Track your progress</p>
                </div>
                <div class="content ">
                    <p class="animate__fadeInUp animate__animated wow text-center">Prepare for NEET 2022 or 2023 with the most thorough and exhaustive online homeroom program by the world's biggest Ed-Tech organization.</p>
                </div>
                <div class="nps-wrap col-12 mt-5">
                    <div class="nps-box">


                        <img src="images/neet-des.png" class="nps-img">

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative paper-wrap" style="overflow:hidden;">
        <img src="images/kenny-eliason-1-aA2Fadydc-unsplash.jpg" class="paper-bk">
        <div class="container position-relative" style="    z-index: 1;">
            <div class="row ">
                <div class="col-md-12">
                    <div class="d-md-flex align-items-center justify-content-between">
                        <div class="main-heaing papper-left">
                            <h2 class="animate__fadeInUp animate__animated wow mb-3 text-white">Build A Stunning Career</h2>
                            <h2 class="mb-5"><span>Sample test for visitors</span></h2>
                            <p class="mt-3 mb-4 text-white">NEET-O=METER is a great platform for your career growth. Get a Regidtration today and have unlimited access of our courses for a lifetime. If not now, when?</p>
                            <a href="javascript:void(0);" onclick="$('.side-menu').addClass('menuopen'); $('body').addClass('overflow-hidden position-relative');" class="main-btn-red">Login</a>
                        </div>
                        <div class="papper-right">
                            <div class="mb-3 owl-carousel owl-theme phy-q-owl">
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Physics</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Physics</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Physics</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Physics</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Physics</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Physics</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Physics</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Physics</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="mb-3 owl-carousel owl-theme chem-q-owl">
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Chemistry</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="owl-carousel owl-theme bio-q-owl">
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Biology</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Biology</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Biology</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Biology</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Biology</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Biology</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Biology</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Biology</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item">
                                    <div class="papper-box">
                                        <h6>The Living World</h6>
                                        <h5>Biology</h5>
                                        <div class="btn-con">
                                            <a href="javascript:void(0)" class="light btn-primary m-0" onclick="openRegister()"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative service-main-wrap">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class=" text-center animate__fadeInUp animate__animated wow">Reasons Why We Are <span>Best</span></h2>
                </div>
                <div class="col-12 why-wrap">
                    <div class="why-box row p-0 m-0">
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/ai.png">
                                <h4>Technology Leaders</h4>
                                <p>We are a team of new-age tech lovers who research & innovate for revolutionary digital solutions that guarantee unmatched performance & growth.</p>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/mocktest.png">
                                <h4>Relationship-Based Model</h4>
                                <p>We build relationships to provide our clients with substantial value through adaptable engagement and pricing structures.</p>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/timetable.png">
                                <h4>One-Stop-Solution</h4>
                                <p>Our complete range of digital solutions reduces costs and provides entire project ownership with excellent quality and prompt delivery.</p>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/performance.png">
                                <h4>Happy Clients</h4>
                                <p>For years, we have delivered custom, data-based, scalable digital innovations for global businesses with cutting-edge solutions.</p>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/exam.png">
                                <h4>Reliable</h4>
                                <p>Our group is active 24/7. You can always rely on us to respond to emergencies, whether they arise on a Sunday, a holiday, or Christmas Eve.</p>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/study-material.png">
                                <h4>Dedicated Team</h4>
                                <p>Receive the same degree of individualized attention regardless of the project's worth with additional support personnel specifically focused on your project.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid testi position-relative mb-5 py-5" id="testi">

        <div class="container position-relative">
            <div class="row">
                <div class="col-12 testi-wrap">
                    <div class="col-12 main-heaing">
                        <h2 class="animate__fadeInUp animate__animated wow text-center text-white">Testimonial</h2>
                    </div>
                    <div class="col-12 animate__fadeInUp animate__animated wow position-relative">
                        <div class="owl-carousel owl-theme testi-owl">
                            <div class="item">

                                <div class="testi-content text-center">
                                    <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out
                                        print, graphicLorem ipsum, or lipsum as it is sometimes known, is dummy text
                                        used in
                                        laying out print, graphic</p>
                                </div>
                                <div class="testi-user d-md-flex align-items-center justify-content-center pt-3">
                                    <img src="images/Frame 319-1.png">
                                    <div>
                                        <h5>Thiago Alcantara</h5>
                                        <h6>Software Engineer</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative" id="faq">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 pt-5 mt-5">
                    <div class="col-12 main-heaing">
                        <h2 class="animate__fadeInUp animate__animated wow text-center ">NEET-O-METER <span>FAQs</span></h2>
                    </div>
                    <div class="col-12 faqbox animate__fadeInUp animate__animated wow">
                        <ul class="faqul">
                            <li>
                                <a class="has-arrow active">
                                    <span class="nav-text">1) What is Lorem Ipsum?</span>
                                </a>
                                <div class="sub-ui" style="display:block ;">
                                    <p class="mb-0">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                                </div>
                            </li>
                            <li>
                                <a class="has-arrow">
                                    <span class="nav-text">2) What is Lorem Ipsum?</span>
                                </a>
                                <div class="sub-ui">
                                    <p class="mb-0">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once("includes/footer.php"); ?>
</body>
<script>
    $(document).ready(function() {
        $('.has-arrow').click(function() {
            if ($(this).hasClass("active")) {
                $(".sub-ui").slideUp();
                $(".has-arrow").removeClass("active");
            } else {
                $(".sub-ui").slideUp();
                $(".has-arrow").removeClass("active");
                $(this).parent().find(".sub-ui").slideToggle();
                $(this).parent().find(".has-arrow").toggleClass("active");
            }
        });
    });
    $('.testi-owl').owlCarousel({
        loop: true,
        margin: 30,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1200: {
                items: 1
            },
            1500: {
                items: 1
            }
        }
    });
    $('.phy-q-owl').owlCarousel({
        loop: false,
        margin: 15,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1200: {
                items: 2
            },
            1500: {
                items: 3
            }
        }
    });
    $('.chem-q-owl').owlCarousel({
        loop: false,
        margin: 15,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1200: {
                items: 2
            },
            1500: {
                items: 3
            }
        }
    });
    $('.bio-q-owl').owlCarousel({
        loop: false,
        margin: 15,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1200: {
                items: 2
            },
            1500: {
                items: 3
            }
        }
    })
</script>
<script>
    const counters = document.querySelectorAll(".counter");

    counters.forEach((counter) => {
        counter.innerText = "0";
        const updateCounter = () => {
            const target = +counter.getAttribute("data-target");
            const count = +counter.innerText;
            const increment = target / 200;
            if (count < target) {
                counter.innerText = `${Math.ceil(count + increment)}`;
                setTimeout(updateCounter, 1);
            } else counter.innerText = target;
        };
        updateCounter();
    });
    function gaugeChart(percentValue,type,chartId)
    {
        
            var randomScalingFactor = function() {
            return Math.round(Math.random() * 100);
        };

            var randomData = function() {
                return [
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor()
                ];
            };
        
            var randomValue = function(data) {
                return Math.max.apply(null, data) * Math.random();
            };
        
            var data = randomData();
            var value = randomValue(data);
       
             
        var config = {
          type: 'gauge',
          data: {
            //labels: ['Success', 'Warning', 'Warning', 'Error'],
            datasets: [{
              data: data,
              value: value,
              backgroundColor: ['#e22328', '#f09120', '#b1ae34', '#0a9447'],
              borderWidth: 0
            }]
          },
          options: {
            responsive: true,
            title: {
              display: false,
              text: type +' Chart'
            },
            layout: {
              padding: {
                bottom: 30
              }
            },
            needle: {
              // Needle circle radius as the percentage of the chart area width
              radiusPercentage: 2,
              // Needle width as the percentage of the chart area width
              widthPercentage: 3.2,
              // Needle length as the percentage of the interval between inner radius (0%) and outer radius (100%) of the arc
              lengthPercentage: 80,
              // The color of the needle
              color: 'rgba(0, 0, 0, 1)'
            },
            valueLabel: {
              formatter: Math.round
            }
          }
        };
         var ctx = document.getElementById(chartId).getContext('2d');
         window.myGauge = new Chart(ctx, config);
    }


 $(document).ready(function () {
     
    //   gaugeChart(40,'Chart 1','chart1');
      gaugeChart(50,'Chart 2','chart2');
      gaugeChart(60,'Chart 3','chart3');
      gaugeChart(70,'Chart 4','chart4');
      gaugeChart(80,'Chart 5','chart5');
      gaugeChart(90,'Chart 6','chart6');
      gaugeChart(74,'Chart 7','chart7');
      gaugeChart(29,'Chart 8','chart8');
 });

   /* var randomScalingFactor = function() {
        return Math.round(Math.random() * 100);
    };

    var randomData = function() {
        return [
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor()
        ];
    };

    var randomValue = function(data) {
        return Math.max.apply(null, data) * Math.random();
    };

    var data = randomData();
    var value = randomValue(data);

    var config = {
        type: 'gauge',
        data: {
            labels: ['Success', 'Warning', 'Warning', 'Error'],
            datasets: [{
                data: data,
                value: value,
                backgroundColor: ['#0b152c', '#3e3f3e', '#dc1e33', '#c32032'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,

            },
            layout: {
                padding: {
                    bottom: 30
                }
            },
            needle: {
                // Needle circle radius as the percentage of the chart area width
                radiusPercentage: 2,
                // Needle width as the percentage of the chart area width
                widthPercentage: 3.2,
                // Needle length as the percentage of the interval between inner radius (0%) and outer radius (100%) of the arc
                lengthPercentage: 80,
                // The color of the needle
                color: 'rgba(14, 30, 42, 1)'
            },
            valueLabel: {
                formatter: Math.round
            }
        }
    };

    window.onload = function() {
        var ctx = document.getElementById('chart').getContext('2d');
        window.myGauge = new Chart(ctx, config);
    };

    document.getElementById('randomizeData').addEventListener('click', function() {
        config.data.datasets.forEach(function(dataset) {
            dataset.data = randomData();
            dataset.value = randomValue(dataset.data);
        });

        window.myGauge.update();
    });*/

</script>

</html>