<div class="container-fluid testi py-6 position-relative" id="testi">
    <img src="images/kenny-eliason-1-aA2Fadydc-unsplash.jpg" class="tst-bk">
    <div class="container position-relative">
        <div class="row">
            <div class="col-12 col-md-6 offset-md-6 my-5" style="    background: #ffffffde;padding: 55px;border-radius: 10px;">
                <div class="col-12 main-heaing">
                    <h2 class="animate__fadeInUp animate__animated wow">Testimonial</h2>
                </div>
                <div class="col-12 animate__fadeInUp animate__animated wow">
                    <div class="owl-carousel owl-theme testi-owl">
                        <div class="item">
                            <div class="testi-user d-md-flex align-items-center pb-3">
                                <img src="images/Frame 319-1.png">
                                <div>
                                    <h5>Thiago Alcantara</h5>
                                    <h6>Software Engineer</h6>
                                </div>
                            </div>
                            <div class="testi-content">
                                <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out
                                    print, graphicLorem ipsum, or lipsum as it is sometimes known, is dummy text
                                    used in
                                    laying out print, graphic</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative" id="faq">
    <div class="container position-relative">
        <div class="row">
            <div class="col-12">
                <div class="col-12 main-heaing">
                    <h2 class="animate__fadeInUp animate__animated wow text-center">NEET-O-METER FAQs</h2>
                </div>
                <div class="col-12 faqbox animate__fadeInUp animate__animated wow">
                    <ul class="faqul">
                        <li>
                            <a class="has-arrow active">
                                <span class="nav-text">1) What is Lorem Ipsum?</span>
                            </a>
                            <div class="sub-ui" style="display:block ;">
                                <p class="mb-0">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                            </div>
                        </li>
                        <li>
                            <a class="has-arrow">
                                <span class="nav-text">2) What is Lorem Ipsum?</span>
                            </a>
                            <div class="sub-ui">
                                <p class="mb-0">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>