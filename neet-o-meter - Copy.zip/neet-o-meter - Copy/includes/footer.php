<footer class="container-fluid ">
    <div class="container h-100">
        <div class="row h-100">
            <div class="col-md-12">
                <div class="ft-logo">
                    <div>
                        <img src="images/ft-logo.png">
                        <p class="mb-0 ft-social text-center mt-4">
                            <a><i class="fab fa-facebook-f"></i></a>
                            <a><i class="fab fa-twitter"></i></a>
                            <a><i class="fab fa-linkedin-in"></i></a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-12 copy-right">
                <div class="d-md-flex align-items-center justify-content-center">
                    <p class="mb-0">© Copyright 2022</p>
                </div>
            </div>
        </div>
    </div>
</footer>